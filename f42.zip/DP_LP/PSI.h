#ifndef PSI_h
#define PSI_h

//#include "randnum.h"
//#include "GS.h"
#include <math.h>
#include <Eigen/Core>
using namespace Eigen;

struct PSIoptions
{
	int L,k,nBurn;
	double eps,delta;
	double ellipsR;
	double pMean_eps;
	bool isPm1Shrinked;	
};
PSIoptions defaultopt();
//ArrayXXd mainPSI(ArrayXXd, PSIoptions);
void outputPSI(PSIoptions);

#endif