#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <Eigen/Core>
#include <Eigen/QR>
#include <windows.system.h>
#include <string>
#include <assert.h>
#include <set>
#include <algorithm>
#include "tuple.h"
#include <string.h>
#include "rand.h"
using namespace std;
using namespace Eigen;

ArrayXXd rtuple(int n, int maxd, int maxnum)
{
  //maxd = 3;
  //maxs = 10;
  int f,r;
  //sa = 0;
  
  //a = new int [n];
  
  ArrayXXd R(maxnum,n);
  
	  int num = 0;
	  for (int i=0;i < n;i++) 
	  {
		  //a[i] = 0;
		  R(0,i) = 0;
	  }
  
  f = 0; r = 1;
  set <string> s;
  
  while (f < r && r < maxnum)
  {
	  string head = "";
	  for (int i = 0; i < n ; i++) head = head + char(int(R(f,i))+48);

	  for (int i = n-1; i>=0 ;i--)	  		  
		  {
			  string tail = head.c_str();
		      tail[i] = char(int(R(f,i))+1+48);
			  if (s.count(tail) == 0)
			  {
				  s.insert(tail);
				  R.row(r) = R.row(f);
				  R(r,i) = R(f,i) + 1;
				  r++;
				  if (r == maxnum) break;
			  }
		  }
	  f++;	
  }
  //cout<<r<<" "<<maxnum<<endl;
  //cout<<R<<endl;
  assert(r == maxnum);
	  
  return R;
}
double regu(double x)
{
	if (x<-1) return -1;
	if (x>1) return 1;
	return x;
}

ArrayXXd cummax(ArrayXXd X,int dim)
{
	ArrayXXd Y = X;
	if (dim == 2)
	{
		for (int i=0; i < X.rows(); i++)
			for (int j = 0; j < X.cols(); j++)
				if (j > 0)
					Y(i,j) = max(Y(i,j),Y(i,j-1));
	}
	return Y;
}

ArrayXXd qr_Q(ArrayXXd X)
{
     MatrixXf A(X.rows(),X.cols());
     for (int i=0;i<A.rows();i++)
		 for (int j =0 ;j<A.cols();j++) A(i,j)=X(i,j);
	 
     HouseholderQR<MatrixXf> qr(A.rows(),A.cols());
	 qr.compute(A);
     MatrixXf Q;
	 Q = qr.householderQ();
	 ArrayXXd res(Q.rows(),Q.cols());
     for (int i=0;i<Q.rows();i++)
		 for (int j =0 ;j<Q.cols();j++) res(i,j)=Q(i,j);
	 return res;
     //thinQ = qr.householderQ() * thinQ;
     //std::cout << "The complete unitary matrix Q is:\n" << Q << "\n\n";
     //std::cout << "The thin matrix Q is:\n" << thinQ << "\n\n";
}
ArrayXXd bsxfun(ArrayXXd X,ArrayXd Y, int dim,char op)
{
	ArrayXXd res = X;
	if (dim == 1)
	{
	    for (int i = 0; i < X.rows(); i++)
			for (int j = 0; j<X.cols(); j++)
			{
				if (op =='+') res(i,j) += Y(i);
				if (op =='-') res(i,j) -= Y(i);
				if (op =='*') res(i,j) *= Y(i);
				if (op =='/') res(i,j) /= Y(i);
			}
	}
	if (dim == 2)
	{
	    for (int i = 0; i < X.rows(); i++)
			for (int j = 0; j<X.cols(); j++)
			{
				if (op =='+') res(i,j) += Y(j);
				if (op =='-') res(i,j) -= Y(j);
				if (op =='*') res(i,j) *= Y(j);
				if (op =='/') res(i,j) /= Y(j);

			}
	}
	return res;		
}
ArrayXXd cumprod1(ArrayXXd X,int dim)
{
	ArrayXXd Y = X;
	if (dim == 2)
	{
		for (int i=0; i < X.rows(); i++)
			for (int j = 0; j < X.cols(); j++)
				if (j > 0)
					Y(i,j) *= Y(i,j-1);
	}
	return Y;
}
ArrayXXd ellgenerate(int n,int d,ArrayXd axe)
{	
    assert(d>=3);
    ArrayXXd r(n,1),x2tod(n,d-1),rs(n,d),phi(n,d-1);
    Random ran;
	r  = ran.getBeta(n,1,d,1);
	if (deb == 1)
	{
	  freopen("rbeta.out","w",stdout);
      cout<<r<<endl;
	}
	phi = ran.getUniform(n,d-1,0,acos(-1.0));
	//for (int i = 0 ; i < phi.rows(); i++) phi(i,d-2) = phi(i,d-2) * 2;
	phi.col(d-2) = phi.col(d-2) * 2;
	if (deb == 1)
	{
		freopen("phi.out","w",stdout);
	    cout<<phi<<endl;
	}
	ArrayXXd cphi = cumprod1(sin(phi),2);
	/*freopen("cphi.out","w",stdout);
	cout<<cphi<<endl;

	/*for (int i=0 ; i <n ;i++)
		for (int j=0;j<d-1;j++)
			x2tod(i,j) = r(i,0) * cphi(i,j);*/
	x2tod = bsxfun(cphi,r.col(0),1,'*');

	/*freopen("x2tod.out","w",stdout);
	cout<<x2tod<<endl;*/

	//x2tod = r*cumprod1(sin(phi),2);
	rs << r,x2tod;

	/*freopen("rs1.out","w",stdout);
	cout<<rs<<endl;*/

	rs.block(0,0,n,d-1) = rs.block(0,0,n,d-1) * cos(phi);
	
			/*freopen("rs2.out","w",stdout);
	cout<<rs<<endl;

				freopen("rs3.out","w",stdout);

	cout<<bsxfun(rs,axe,2,'*')<<endl;*/
	/*for (int i = 0; i< rs.rows();i++)
		for (int j =0 ; j<d-1 ;j++)
			rs(i,j) *= phi(i,j);*/

	/*for (int i = 0; i< n;i++)
		for (int j =0 ; j<d ;j++)
			rs(i,j) *= axe(j);*/	
	return bsxfun(rs,axe,2,'*');
}
ArrayXXd mult(ArrayXXd a, ArrayXXd b)
{
	assert(a.cols()==b.rows());
	ArrayXXd c = a.matrix()*b.matrix();
	/*for (int i= 0; i<a.rows();i++)
		for (int j =0 ; j<b.cols();j++){
			c(i,j)= 0;
			for (int k= 0;k<a.rows();k++) c(i,j) += a(i,k)*b(k,j);
		}
		*/	
	return c;
}
ArrayXd pMean(ArrayXXd D,double eps)
{
	//mD = mean(D) + laprnd(2*d/(n*eps), [1 d]); % Dp mean
	Random ran;    
	ArrayXd res;
	int n,d;
	n = D.rows(),d = D.cols();
	ArrayXXd noise = ran.getLaplace(d,1,2*d/(n*eps));
	res = D.colwise().mean();
	if (deb!= 1)
		res = res + noise.col(0);
	return res;
}
ArrayXXd cov(ArrayXXd D)
{	
	int n = D.rows(),m = D.cols();
	ArrayXd  aver = D.colwise().mean();
	D = bsxfun(D,aver,2,'-');
	
	if (n>1)
		D = mult(D.transpose(),D)/(n-1);
	else D = mult(D.transpose(),D)/n;
	return D;
}

ArrayXXd ktuple(ArrayXXd D,int C_size,PSIoptions opt)
{
	/*	                eps = options.cGrids_PSI_eps;
                    delta = options.cGrids_PSI_delta;
                    nBurn = options.cGrids_PSI_nBurn;
                    ellipsR = options.cGrids_PSI_ellipsR;
                    isPm1Shrinked = options.cGrids_PSI_isPm1Shrinked; % Default true
					 kFun = options.cGrids_PSI_kFun;*/
	 int n,d;
	 Random ran;
	 ArrayXXd Grids,tmp,A,X,Xt,Wl,W,G;
     n =  D.rows();d = D.cols();
	 if (opt.k>d) opt.k = d;
	 ArrayXd sigma(opt.k);
     
     for (int i =0 ; i< opt.k ; i++) 
	 {		 
			 sigma(i) = 5*d*sqrt((i+1)*2*opt.nBurn*log(2/opt.delta))/(n*opt.eps);	 
	 }
	 if (deb == 1){
	 freopen("sigma.out","w",stdout);
	 cout<<sigma<<endl;
	 }
	 outputPSI(opt);
     A = cov(D);
	 /*freopen("data.out","w",stdout);
	 cout<<D<<endl;*/
	 /*freopen("covD.out","w",stdout);
	 cout<<A<<endl;*/
	 
     G = ran.getNormal(d, opt.k,0,1);
	 char fname[100],gname[100];
 	 

	 if (deb == 1)
	 {
		 strcpy(fname,"GaussA.out");

	     freopen(fname,"w",stdout);
	     cout<<G<<endl;
	 }

	 Xt = qr_Q(G);                   	
	 X = Xt.block(0,0,Xt.rows(),opt.k);
     /*freopen("X.out","w",stdout);
	 cout<<X<<endl;*/

	 for (int i = 0; i<opt.nBurn+1; i++)
	 {
		 ArrayXXd t1;ArrayXd t2(opt.k);
         t1 = ran.getNormal(d, opt.k,0,1);
		 if (deb == 1)
		{
			fname[5] = char(i+'A'+1);
	        freopen(fname,"w",stdout);
    	    cout<<t1<<endl;
		 }
		 for (int j =0 ; j < opt.k; j++)
		 {
			 t2(j) = abs(X).col(j).maxCoeff();
		     if (j>0) t2(j) = max(t2(j-1),t2(j));
		 }	  
		 G = bsxfun(t1, t2*sigma,2,'*');
		 /*if (i ==0 )
		 {

 			      freopen("G_r.out","w",stdout);
	              cout<<t2*sigma<<endl;

			      freopen("G.out","w",stdout);
	              cout<<G<<endl;

		 }*/
	   	 Wl = A.matrix()*X.matrix() + G.matrix();
		 /*strcpy(gname,"W0.out");
		 gname[1] = i+49;
		 
		 freopen(gname,"w",stdout);
		 cout<<Wl<<endl;*/

		 if (i == opt.nBurn) 
		 {
			 
			 W = Wl;
			 break;
		 }
	 	 Xt = qr_Q(Wl);
         X = Xt.block(0,0,Xt.rows(),opt.k);
	 }

	 
	 tmp = W.transpose().matrix() * W.matrix();

     ArrayXd lambda(d);
     for (int i = 0 ; i < d ; i++)
		 if (i<opt.k) lambda(i) = sqrt(tmp(i,i)); else lambda(i) = 0 ;


	 if (deb == 1)
	{
			 freopen("lambda.out","w",stdout);
	         cout<<lambda<<endl;
	 }

	 ArrayXXd tGrids,rGrids(d,d);
	
	 ArrayXd axe;
	 axe = opt.ellipsR*sqrt(lambda);

	 if (deb == 1)
	 {
			 freopen("axe.out","w",stdout);
	         cout<<axe<<endl;
	 }
	 tGrids =  ellgenerate(C_size, d ,axe);
	 
	 if (d-opt.k>0)
		 rGrids <<X,ArrayXXd::Zero(d,d-opt.k);
	 else rGrids = X;

	 if (deb == 1)
	 {
		 freopen("X.out","w",stdout);
		 cout<<X<<endl;
	 }
	 
	 ArrayXd pM = pMean(D,opt.pMean_eps);
	 /*for (int i = 0 ; i < Grids.rows();i++)
		 for (int j =0 ; j<Grids.cols();j++)
			 Grids(i,j)+=pM(j);*/
	 if (deb == 1)
	 {
		 freopen("tGrids.out","w",stdout);
	     cout<<tGrids<<endl;
	 
	     freopen("rGrids.out","w",stdout);
	     cout<<rGrids<<endl;
	     freopen("pMean.out","w",stdout);
	     cout<<pM<<endl;
	 }

	 ArrayXXd G1 = tGrids.matrix()*rGrids.transpose().matrix();
	 if (deb == 1)
	 {
		 freopen("G1.out","w",stdout);
		 cout<<G1<<endl;
	 }
	 Grids = bsxfun(G1,pM,2,'+') ;
	 
	 
     if (opt.isPm1Shrinked)
		 Grids = Grids.unaryExpr(ptr_fun(regu)); // We regulate the selected Grid between -1 and 1

     return Grids; 
}
ArrayXXd ktuple_rand(int n, int  maxd,int maxs)
{
    ArrayXXd K(maxs,n);
    set <string> s;

	for (int i = 0;i< K.rows();)
	{
		string tmp = "";
		for (int j = 0 ; j< K.cols(); j++)
		{
			K(i,j) = rand()%maxd;
			tmp = tmp + char(int(K(i,j))%256);
		}
		if (s.count(tmp) == 0)
		{
			i ++;
			s.insert(tmp);
		}
	}
	//cout<<"K"<<K<<endl;
	return K;
}
