#pragma once

#include <cmath> 
#include <ctime> 
#include <cstdlib> 
#include <Eigen/Core>
using namespace Eigen;
class Random 
{ 
public: 
	void init(unsigned int seed) ;
	void init() ;
	
	Random() ;
	
	~Random() ;
	double getLast() ;
	
	double getUniform(double ,double ) ;
    ArrayXXd getUniform(int ,int ,double,double ) ;
	double getLaplace(double );
	ArrayXXd getLaplace(int ,int ,double );
	 
	double getGamma(double ,double ) ;
	
	double getBeta(double ,double ) ;
	

	ArrayXXd getBeta(int ,int ,double ,double ) ;
	

	double getNormal(double ,double ) ;
	
	ArrayXXd getNormal(int ,int ,double ,double ) ;
	

	double getExponentail(double ) ;
	
	int getDiscreteUniform(int ,int )  ;
	
	int getGeometric(double ) ;
	
	int getBinomial(int ,double ) ;
	
	int getPoisson(double ) ;
	
private: 
	double uniform() ;
	
private: 
	double lastNumber; 
}; 
 
#include <fstream> 
