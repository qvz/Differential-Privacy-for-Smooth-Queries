//#include <ilcplex/ilocplex.h>
#include <fstream>
#include <sstream>
#include <limits>
#include <string>
#include <iostream>
#include <Eigen/Core>
#include "tuple.h"
#include <cstdio>
#include <windows.system.h>
#include "rand.h"
#include "cplex.cpp"
#include <vector>
#include <cassert>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include "parameters.h"
using namespace Eigen; 
using namespace std;
const int myrand_max = (1<<30);
inline int myrand(){ // 30-bit integer
	return ((rand()&((1<<15)-1))<<15)+(rand()&((1<<15)-1));
}


//const int myrand_max = RAND_MAX+1;
//inline int myrand(){ // 30-bit integer
//	return rand();
//}
inline double myrand_f(){
	return myrand()*1.0/myrand_max;
}

ArrayXXd sample(const ArrayXXd& grids, const ArrayXd& prob, int m){
	assert(grids.rows() <= prob.rows());
	ArrayXXd ret(m, grids.cols());
	vector<double> acc(1,prob(0));
	for (int i=1; i<grids.rows(); ++i)
		acc.push_back(acc.back()+prob(i));
	assert(abs(acc.back()-1)<1e-7);
	for (int i=0; i<m; ++i){
		double p = myrand_f();
		int idx = lower_bound(acc.begin(), acc.end(), p) - acc.begin();
		assert(idx<grids.rows());
		ret.row(i) = grids.row(idx);
	}
	return ret;
}
inline double sqr(double x){
	return x*x;
}
double query(const ArrayXd& x, const ArrayXXd& X, double sigma){
	assert(x.rows()==X.cols());
	double ret = 0;
	for (int i=0; i<X.rows(); ++i){
		double t = 0;
		for (int j=0; j<X.cols(); ++j)
			t += sqr(x(j)-X(i,j));	
		ret += exp(-t/2/sqr(sigma));
	}
	return ret/X.rows();
}


const int n_J = 10;
void test_query(const ArrayXXd& org_D, const ArrayXXd& syn_D, double sigma,
			   ArrayXd& abs_err, ArrayXd& rel_err){
	assert(org_D.cols() == syn_D.cols());
	assert(abs_err.rows() == n_sample_Q);
	assert(rel_err.rows() == n_sample_Q);

	ArrayXd org_q(n_sample_D), syn_q(n_sample_D);	
#pragma omp parallel for
	for (int i = 0; i<n_sample_D; ++i){
		ArrayXd x(org_D.cols());
		for (int j=0; j<x.rows(); ++j)
			x(j) = myrand_f()*2-1;
		org_q(i) = query(x, org_D, sigma);
		syn_q(i) = query(x, syn_D, sigma);	
	}

#pragma omp parallel for
	for (int i=0; i<n_sample_Q; ++i){
		double t1=0, t2=0;
		double ss = 0;
		for (int j=0; j<n_J; ++j){
			double b = myrand_f();
			ss += b;
			int idx = myrand()%org_q.rows();
			t1 += b*org_q(idx);
			t2 += b*syn_q(idx);
		}
		//cerr<<ss<<endl<<t1<<"  "<<t2<<endl;
		t1 /= ss;
		t2 /= ss;
		abs_err(i) = abs(t1-t2);
		rel_err(i) = abs_err(i)/abs(t1);
		//cerr<<abs_err(i)<<" "<<rel_err(i)<<endl;
	}
}

//ILOSTLBEGIN
Eigen::ArrayXXd csvRead (std::ifstream &data)
{
	std::string		line;
	unsigned		i, j;
	vector <double> tmpdata;
	unsigned r = 0,c=0;
	for (i = 0; std::getline(data,line); i++)
	{
		std::stringstream	lineStream(line);
		std::string			cell;
		for (j = 0; std::getline(lineStream, cell, ',');j++) 
		{
			    if (i == 0) c = j+1;
				tmpdata.push_back( atof(cell.c_str()) );
		}
	}
	r = i;

	Eigen::ArrayXXd	result(r,c);

	for (i = 0; i<r; i++)
		for (j = 0;j<c; j++)
			result(i,j) = tmpdata[i*c+j];

	return result;//.block(0,1,result.rows(),3);
}

Eigen::ArrayXd typeRead (int n)
{
    FILE *fp;
	fp = fopen(type_filename, "r");
	ArrayXd ty(n);
	
	for (int i = 0; i<n ; i++)
	{
		char cell[100],cell1[100];
		fscanf(fp,"%s%s",cell,cell1);		
	    if (cell1[0] == 'b') ty(i) = -1;
		else ty(i) = 1;
		
	}
	fclose(fp);
	return ty;//.block(0,1,result.rows(),3);
}

	//discrete domain
double discreteone(double x, const unsigned N)
{
	return -1-1.0/N+2.0/N*max(ceil((x+1)*N/2),1);
}

Eigen::ArrayXXd discretize(Eigen::ArrayXXd data, const unsigned N)
{
	for (int i = 0; i < data.rows(); i++)
		for (int j = 0 ;j < data.cols(); j++)
			data(i,j) = acos(discreteone(data(i,j),N));
    return data;
}
void prepro(Eigen::ArrayXXd data, int N, int d,int C_size,int R_size,double eps,Eigen::ArrayXd &u, ArrayXXd& grid)

{

	Eigen::ArrayXXd Theta = discretize(data,N);	

	Eigen::ArrayXXd r = rtuple (d,para_t,R_size);       //** * d

	Eigen::ArrayXXd k = ktuple(data,C_size,opt);         //** * d
	if (deb == 1)
	{
		freopen("rtuple.out","w",stdout);
		cout<<r<<endl;
		freopen("ktuple.out","w",stdout);
		cout<<k<<endl;
	}
	double s;
	Eigen::ArrayXd b(R_size),lapn(R_size,1);
    Random ran;
    //lap.generate(R_size/(data.rows()*eps));;
	lapn = ran.getLaplace( R_size , 1,R_size/(data.rows()*eps));

	for (int i = 0; i < R_size ; i++)
	{
		Eigen::ArrayXXd tmp(Theta.rows(),Theta.cols());
		for (int j = 0 ; j < Theta.rows(); j++)
			tmp.row(j) = r.row(i) * Theta.row(j);
		s = cos(tmp).rowwise().prod().mean();
		
		b(i) = s + lapn(i,0);
		if (deb == 1) b(i) = s;
	}

	
	Eigen::ArrayXXd w(r.rows(),k.rows());
	grid = k;
	for (int i = 0; i < k.rows(); i++) //k tuple
	    for (int j = 0; j < r.rows(); j++)  //r tuple 
		{
			w(j,i) = 1;
			for (int l =0 ;l < r.cols(); l++)
    			w(j,i) *= cos(acos(grid(i,l)) * r(j,l));
		}

	Eigen::Array<double, -1, -1, Eigen::RowMajor, -1, -1> aineq(2*R_size,C_size+R_size);
	Eigen::ArrayXXd eyeR(R_size,R_size);
	for (int i = 0;i < R_size;i++)
		for (int j = 0 ; j < R_size; j++)
			if (i==j) eyeR(i,j) = 1;
			else eyeR(i,j) = 0;

	aineq << w,-eyeR,
		    -w,-eyeR;
	//aineq.block(w.rows(),w.cols(),R_size,R_size) = -eyeR;
	
	
	Eigen::ArrayXd bineq(b.rows()*2);
	bineq << b,
		    -b;
	
	Eigen::RowVectorXd f_cplex(C_size+R_size);
	Eigen::Array<double, -1, -1, Eigen::RowMajor, -1, -1> Aeq(1,C_size+R_size);
	for (int i = 0; i< C_size+R_size;i++)
	{
		if (i<C_size) f_cplex(i) = 0.0 ; else f_cplex(i) = 1.0;
		if (i<C_size) Aeq(0,i) = 1.0 ; else Aeq(0,i) = 0.0;
	}
	Eigen::ArrayXd beq(1);
	beq << 1.0;
	

	Eigen::ArrayXd lb(C_size+R_size);
	Eigen::ArrayXd ub(C_size+R_size);
	for (int i=0;i<lb.rows();i++)
	{
		lb(i) = 0.0;
		if (i<C_size) ub(i) = upb_cst/C_size; else ub(i) = 1e300;
	}
	u = lb;
	if (deb == 1)
		freopen("log.out","w",stdout);

	cplexlp(f_cplex,aineq,bineq,Aeq,beq,lb,ub,u);

	if (deb == 1)
	{
		freopen("u.out","w",stdout);
		cout<<u<<endl;
		freopen("u0.out","w",stdout);
		for (int i = 0; i<R_size+C_size;i++)
		  if (u(i)>0) cout<<u(i)<<endl;
	}


}
ArrayXXd scale(ArrayXXd data,ArrayXd &maxcol,ArrayXd &mincol)
{
	maxcol = data.colwise().maxCoeff();
	mincol = data.colwise().minCoeff();
	for (int i = 0; i<data.cols();i++)
		if (maxcol(i)-mincol(i)<1e-5) 			
				maxcol(i) = mincol(i)+0.01;
	ArrayXd range = maxcol-mincol;
	data = bsxfun(data,mincol,2,'-');
	return bsxfun(data,range,2,'/')*2-1;
}
ArrayXXd unscale(ArrayXXd data,ArrayXd maxcol,ArrayXd mincol)
{
	data = (data + 1)/2;
	ArrayXd range = maxcol -mincol;
	data = bsxfun(data,range,2,'*');
	return bsxfun(data,mincol,2,'+');
}
int main (int argc, char **argv)
{
	assert(argc==2);
	parse_config_file(argv[1]);
    
	srand(13);
	initParallel();
	setNbThreads(1);



	cout << "options got/read indata from "<<csv_filename<<endl;
	ifstream	indata(csv_filename, std::ifstream::in);
		

	Eigen::ArrayXXd data = csvRead (indata);
	

	ArrayXd maxcol,mincol;

	data = scale(data,maxcol,mincol);



	Eigen::ArrayXd u(C_size+R_size);

	ArrayXXd grids;
	prepro(data,N,data.cols(),C_size,R_size,eps,u, grids);
	ArrayXXd syn_D = sample(grids, u, m);
	
	//ArrayXd abs_err(n_sample_Q), rel_err(n_sample_Q);
	//test_query(data, syn_D, 2, abs_err, rel_err);
	//cout<<abs_err.mean()<<endl<<rel_err.mean()<<endl;
	
	

	ArrayXd ty = typeRead(data.cols());

	FILE *fp = fopen(output_filename,"w");
	for (int i =0 ; i<syn_D.rows();i++)
	{
		for (int j =0 ; j<syn_D.cols();j++)		
			if (ty(j) < 0)
				if (syn_D(i,j)>0) syn_D(i,j) = 1; else syn_D(i,j) = -1;
	
	}

	syn_D = unscale(syn_D,maxcol,mincol);
	
	for (int i =0 ; i<syn_D.rows();i++)
	{
		for (int j =0 ; j<syn_D.cols();j++)
		{
		    if ( j > 0) fprintf(fp,",");
			fprintf(fp,"%.5f",syn_D(i,j));				
		}
		fprintf(fp,"\n");
	}	
	fclose(fp);
	return 0;
}
