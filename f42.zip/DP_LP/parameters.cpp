#pragma once
#include <cstring>
#include <cstdio>
#include "PSI.h"
#include <iostream>
using namespace std;

int R_size = 79;
int C_size = 10000;
int N = 100;
double eps = 1;
int para_t = 3;
int m = 100000;
double sigma = 2.0;
int n_sample_D = 10000; // number of test points
int n_sample_Q = 100000; // number of queries
char csv_filename[100] = "WDBC_scaled.csv";
extern double upb_cst = 100.0;
char log_filename[100] = "LP.log";

char output_filename[100] = "output.txt";
char type_filename[100] = "type.txt";
int deb = 0;

PSIoptions opt = defaultopt();

static char buf1[100000], buf2[1000];
void parse_config_file(const char *s){

	FILE *cf = fopen(s, "r");
	while (fgets(buf1, 100000, cf)!=NULL){
		sscanf(buf1, "%s", buf2);
		if (strcmp(buf2, "R_size")==0)
			sscanf(buf1, "%*s%d", &R_size);
		else if (strcmp(buf2, "C_size")==0)
			sscanf(buf1, "%*s%d", &C_size);
		else if (strcmp(buf2, "N")==0)
			sscanf(buf1, "%*s%d", &N);
		else if (strcmp(buf2, "eps")==0)
			sscanf(buf1, "%*s%lf", &eps);
		else if (strcmp(buf2, "para_t")==0)
			sscanf(buf1, "%*s%d", &para_t);
		else if (strcmp(buf2, "sigma")==0)
			sscanf(buf1, "%*s%lf", &sigma);
		else if (strcmp(buf2, "m")==0)
			sscanf(buf1, "%*s%d", &m);
		else if (strcmp(buf2, "n_sample_D")==0)
			sscanf(buf1, "%*s%d", &n_sample_D);
		else if (strcmp(buf2, "n_sample_Q")==0)
			sscanf(buf1, "%*s%d", &n_sample_Q);
		else if (strcmp(buf2, "csv_filename")==0)
			sscanf(buf1, "%*s%s", csv_filename);
		else if (strcmp(buf2, "output_filename")==0)
			sscanf(buf1, "%*s%s", output_filename);
		else if (strcmp(buf2, "type_filename")==0)
			sscanf(buf1, "%*s%s", type_filename);
		else if (strcmp(buf2, "log_filename")==0)
			sscanf(buf1, "%*s%s", log_filename);
		else if (strcmp(buf2, "k")==0)
			sscanf(buf1, "%*s%d", &opt.k);
		else if (strcmp(buf2, "n_PSI")==0)
			sscanf(buf1, "%*s%d", &opt.nBurn);
		else if (strcmp(buf2, "eps_PSI")==0)
			sscanf(buf1, "%*s%lf", &opt.eps);
		else if (strcmp(buf2, "delta_PSI")==0)
			sscanf(buf1, "%*s%lf", &opt.delta);
		else if (strcmp(buf2, "ellipsR")==0)
			sscanf(buf1, "%*s%lf", &opt.ellipsR);
		else if (strcmp(buf2, "pMean_eps")==0)
			sscanf(buf1, "%*s%lf", &opt.pMean_eps);
		else if (strcmp(buf2, "isPm1Shrinked")==0)
			sscanf(buf1, "%*s%d", &opt.isPm1Shrinked);
		else if (strcmp(buf2, "upb_cst")==0)
			sscanf(buf1, "%*s%lf", &upb_cst);

	}
}