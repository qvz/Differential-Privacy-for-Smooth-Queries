/* Bring in the CPLEX function declarations and the C library 
   header file stdio.h with the following single include. */

#include <ilcplex/cplex.h>
#include <Eigen/Dense>
/* Bring in the declarations for the string functions */
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <stdexcpt.h>
/* Include declaration for functions at end of program */

static int
cplexlp		(Eigen::RowVectorXd &f_cplex, 
			Eigen::Array<double, -1, -1, Eigen::RowMajor, -1, -1> &Aineq,
			Eigen::ArrayXd &bineq,
			Eigen::Array<double, -1, -1, Eigen::RowMajor, -1, -1> &Aeq,
			Eigen::ArrayXd &beq,
			Eigen::ArrayXd &lb,
			Eigen::ArrayXd &ub,
			Eigen::ArrayXd &solution);

template <typename T> int sgn(T val) {
    return (T(0) < val) - (val < T(0));
};

//---------- implementation of L^0 norms ----------
static void
   free_and_null     (char **ptr),
   usage             (char *progname);


static int
cplexlp(Eigen::RowVectorXd &f_cplex, 
		Eigen::Array<double, -1, -1, Eigen::RowMajor, -1, -1> &Aineq,
		Eigen::ArrayXd &bineq,
		Eigen::Array<double, -1, -1, Eigen::RowMajor, -1, -1> &Aeq,
		Eigen::ArrayXd &beq,
		Eigen::ArrayXd &lb,
		Eigen::ArrayXd &ub,
		Eigen::ArrayXd &solution)
{
	int	status = 0;
	CPXENVptr	env = NULL;
	CPXLPptr	lp  = NULL;
	int solstat;
	double objval;
	char errmsg[CPXMESSAGEBUFSIZE];

	/* Turn on output to the screen */
	env = CPXopenCPLEX (&status);

	/* If the environment cannot open, we throw the runtime error */
	if ( env == NULL ) {
		CPXgeterrorstring (env, status, errmsg);
		throw std::runtime_error(errmsg);
		goto TERMINATE;
	}

	/* Turn on output to the screen */
	status = CPXsetintparam (env, CPX_PARAM_SCRIND, CPX_ON);
	if ( status ) {
		sprintf_s(errmsg, "Failure to turn on screen indicator, error %d.\n", status);
		throw std::runtime_error(errmsg);
		goto TERMINATE;
	}

	/* Turn on data checking */
	status = CPXsetintparam (env, CPX_PARAM_DATACHECK, CPX_ON);
	if ( status ) {
		sprintf_s(errmsg, "Failure to turn on data checking, error %d.\n", status);
		throw std::runtime_error(errmsg);
		goto TERMINATE;
	}

	/* Switch parallel mode to opportunistic */
	status = CPXsetintparam (env, CPX_PARAM_PARALLELMODE, CPX_PARALLEL_OPPORTUNISTIC);
	if ( status ) {
		sprintf_s(errmsg, "Failure to turn on CPLEX parallel mode, error %d.\n", status);
		throw std::runtime_error(errmsg);
		goto TERMINATE;
	}

	/* Create the problem */
	lp = CPXcreateprob (env, &status, "DP");
	if ( lp == NULL ) {
		sprintf_s(errmsg, "Failed to create LP.\n", status);
		throw std::runtime_error(errmsg);
		goto TERMINATE;
	}

	/* Populate the problem */
	int cols = f_cplex.cols(),
		row_ineq = bineq.rows(),
		row_eq = beq.rows(),
		zero = 0,
		i, j,
		*ind = NULL;
	ind = (int*) malloc(cols * sizeof(int));
	if ( ind == NULL ) {
		status = CPXERR_NO_MEMORY;
		goto TERMINATE;
	}
	for (j = 0; j < cols; j++) {
		ind[j] = j;
	}

	/* Declare the model variables with lb <= solution <= ub */
	status = CPXnewcols (env, lp, cols, f_cplex.data(), lb.data(), 
		ub.data(), NULL, NULL);
	if ( status )  goto TERMINATE;

	/* Adding `L' constraints */
	for (i = 0; i < row_ineq; i++) {
		status = CPXaddrows (env, lp, 0, 1, cols, bineq.row(i).data(), "L", 
			&zero, ind, Aineq.row(i).data(), NULL, NULL);
		if ( status ) {
			sprintf_s(errmsg, "Failed to add L constraints.\n");
			goto TERMINATE;
		}
	}

	/* Adding `E' constraints */
	for (i = 0; i < row_eq; i++) {
		status = CPXaddrows (env, lp, 0, 1, cols, beq.row(i).data(), "E", 
			&zero, ind, Aeq.row(i).data(), NULL, NULL);
		if ( status ) {
			sprintf_s(errmsg, "Failed to add E constraints.\n");
			goto TERMINATE;
		}
	}

	/* First we clear the big Aineq for memory */
	Aineq.resize(0, 0);

	/* Optimize the problem */
	status = CPXlpopt(env, lp);
	
	if ( status ) {
		sprintf_s(errmsg, "Failed to optimize LP.\n", status);
		goto TERMINATE;
	}

	status = CPXsolution(env, lp, &solstat, &objval, solution.data(), NULL, NULL, NULL);

	if ( status ) {
		sprintf_s(errmsg, "Failed to obtain solution.\n");
		goto TERMINATE;
	}

TERMINATE:

	if ( lp != NULL ) {
		status = CPXfreeprob (env, &lp);
		if ( status ) {
			sprintf_s(errmsg, "CPXfreeprob failed, error code %d.\n", status);
		}
	}

	/* Free up the CPLEX environment, if necessary */
	if ( env != NULL ) {
		status = CPXcloseCPLEX (&env);
		if ( status > 0 ) {
			fprintf (stderr, "Could not close CPLEX environment.\n");
			CPXgeterrorstring (env, status, errmsg);
			fprintf (stderr, "%s", errmsg);
		}
	}
	if (status ) {
		fprintf_s (stderr, errmsg);
	}
	return (status);
}

/* This simple routine frees up the pointer *ptr, and sets *ptr to NULL */

static void
free_and_null (char **ptr)
{
   if ( *ptr != NULL ) {
      free (*ptr);
      *ptr = NULL;
   }
} /* END free_and_null */  

static void
usage (char *progname)
{
   fprintf (stderr,"Usage: %s -riq <row_ineq> -req <row_eq> -c <col> \n", progname);
   fprintf (stderr," Exiting...\n");
}