#include "PSI.h"
#include <iostream>
using namespace std;
/*	int L,k,nBurn;
	double eps,delta;
	double ellipsR;
	double pMean_eps;
	bool isPm1Shrinked;	
*/

void outputPSI(PSIoptions opt)
{
	
}

PSIoptions defaultopt()
{
	PSIoptions opt;
	opt.L = 5,opt.k = 3, opt.nBurn = 5 ,opt.eps = 1,opt.delta = 1e-5 ,opt.ellipsR =3 ,opt.pMean_eps = 1,opt.isPm1Shrinked=true;
	return opt;
}

/*ArrayXXd mainPSI(ArrayXXd D, PSIoptions opt)
{
	ArrayXXd A;
	ArrayXXd G,X,Xn,W;
	int n = D.rows(), d = D.cols();
	double sigma = 5 * d *sqrt(4 * opt.k*opt.L*log(1/opt.delta))/ (n*opt.eps);
	A = (1.0/n)*D*D.transpose() - D.rowwise().mean() * D.rowwise().mean().transpose();
	gaussian gauss;
	G = gauss.generate(d,opt.k);
	X = GS(G);
	for (int it = 1; it <= opt.L; it++)
	{
		G = gauss.generate(n,opt.k) * sigma;
		W = A * X + X.maxCoeff() * G;
		Xn = GS(W);
		X = Xn;

	}
	return X;	
}*/