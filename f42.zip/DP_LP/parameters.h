#ifndef PARAMETERS_H
#define PARAMETERS_H
extern int C_size;
extern int R_size;
extern int N;
extern double eps;
extern double upb_cst;
extern int m;
extern int para_t;
extern int n_sample_D; // number of test points
extern int n_sample_Q; // number of queries
extern char csv_filename[100];
extern char output_filename[100];
extern char log_filename[100];
extern char type_filename[100];
extern PSIoptions opt;
extern int deb;


void parse_config_file(const char *config_filename);
#endif