#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <Eigen/Core>
#include <windows.system.h>
#include "PSI.h"
#include "parameters.h"
#include "randnum.h"
using namespace Eigen;

bool getnext(int * a,int &sa);

ArrayXXd rtuple(int, int, int);

ArrayXXd ktuple(ArrayXXd,int, PSIoptions);
ArrayXXd ktuple_rand(int,int,int);

ArrayXXd bsxfun(ArrayXXd, ArrayXd,int,char);
